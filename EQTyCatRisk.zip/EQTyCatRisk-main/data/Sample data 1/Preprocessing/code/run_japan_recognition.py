#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Recognize simultaneous events from the two Japan-only catalogues.

The earthquake catalogue is the KIK Japan catalogue and the typhoon
catalogue is the Japan-only 2001--2026 summary.  The latter stores maximum
wind in kt and the 30KT long/short radii in km.  For the coupling test we use
the original 30KT long radius directly as the R30 circle radius; the short
radius is not averaged into the spatial criterion.
"""
from __future__ import annotations

import argparse
import bisect
import csv
import math
from datetime import datetime, timedelta, timezone
from pathlib import Path

EARTH_KM = 6371.0088
KNOT_TO_MS = 0.514444
WINDOW_HOURS = 72.0
JST = timezone(timedelta(hours=9))
UTC = timezone.utc

MAIN_COLUMNS = [
    "z_id", "coupling_type", "eq_time", "eq_lat", "eq_lon", "Mw", "depth_km",
    "tc_time", "tc_lat", "tc_lon", "wind_kt", "wind_ms", "dt_hours",
    "distance_km", "R30_km", "R30_long_km", "R30_short_km",
]
TRACK_COLUMNS = ["z_id", "coupling_type", "times", "lats", "lons", "winds", "winds_kt"]


def number(value: object) -> float | None:
    try:
        text = str(value).strip().replace(",", "")
        if not text or text.lower() in {"nan", "na", "null", "-", "--"}:
            return None
        parsed = float(text)
        return parsed if math.isfinite(parsed) else None
    except (TypeError, ValueError):
        return None


def parse_eq_time(value: object) -> datetime | None:
    text = str(value or "").strip().replace("/", "-")
    for fmt in ("%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d %H:%M:%S"):
        try:
            # The earthquake catalogue's Origin Time is already JST.
            return datetime.strptime(text, fmt).replace(tzinfo=JST)
        except ValueError:
            pass
    return None


def parse_ty_time(year: int, month: int, day: int, hour: int) -> datetime:
    # The typhoon catalogue explicitly stores UTC; convert it to JST once.
    utc_moment = datetime(year, month, day, hour, tzinfo=UTC)
    return utc_moment.astimezone(JST)


def iso(value: datetime) -> str:
    return value.astimezone(JST).strftime("%Y-%m-%d %H:%M:%S")


def utc_timestamp(value: datetime) -> float:
    """Return a timezone-independent POSIX timestamp from an aware datetime."""
    return value.astimezone(UTC).timestamp()


def distance_km(lat1: float, lon1: float, lat2: float, lon2: float) -> float:
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dlat, dlon = p2 - p1, math.radians(lon2 - lon1)
    a = math.sin(dlat / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dlon / 2) ** 2
    return EARTH_KM * 2 * math.asin(min(1.0, math.sqrt(a)))


def read_rows(path: Path) -> list[list[str]]:
    # These files are Japanese CSVs; gb18030 also handles the legacy export
    # used in the project and errors=replace keeps the numeric columns intact.
    with path.open("r", encoding="gb18030", errors="replace", newline="") as handle:
        return list(csv.reader(handle))


def missing_required_fields(fields: list[tuple[str, object]]) -> list[str]:
    """Return required field names whose parsed values are missing or invalid."""
    def invalid(value: object) -> bool:
        if value is None:
            return True
        if isinstance(value, str):
            return value.strip().lower() in {'', 'nan', 'na', 'null', 'none', '-', '--'}
        return isinstance(value, float) and not math.isfinite(value)
    return [name for name, value in fields if invalid(value)]


def load_earthquakes(path: Path, audit: list[dict] | None = None) -> list[dict]:
    audit = audit if audit is not None else []
    candidates: dict[str, list[tuple[dict, int]]] = {}
    for line_number, row in enumerate(read_rows(path)[1:], 2):
        if len(row) < 6:
            audit.append({'catalog': 'earthquake', 'line': line_number, 'reason': 'invalid', 'fields': 'short row'})
            continue
        moment = parse_eq_time(row[1])
        lat, lon, depth, mag = map(number, (row[2], row[3], row[4], row[5]))
        identifiers = [row[16].strip() if len(row) > 16 else '', row[0].strip()]
        event_id = next((value for value in identifiers if value and value.lower() not in {'nan', 'na', 'null', 'none', '-', '--'}), '')
        missing = missing_required_fields([('earthquake_id', event_id), ('origin_time', moment), ('latitude', lat), ('longitude', lon), ('magnitude', mag)])
        if missing:
            audit.append({'catalog': 'earthquake', 'line': line_number, 'reason': 'invalid', 'fields': ','.join(missing), 'key': event_id})
            continue
        item = {"id": event_id, "time": moment, "lat": lat, "lon": lon, "depth": depth, "mag": mag}
        candidates.setdefault(event_id, []).append((item, line_number))
    result = []
    for key, records in candidates.items():
        first, first_line = records[0]
        if any(item != first for item, _ in records[1:]):
            for _, line in records:
                audit.append({'catalog': 'earthquake', 'line': line, 'reason': 'conflict', 'fields': 'same ID, different attributes; all excluded', 'key': key})
            continue
        if first['mag'] >= 5.0 and 20 <= first['lat'] <= 50 and 120 <= first['lon'] <= 155:
            result.append(first)
        else:
            audit.append({'catalog': 'earthquake', 'line': first_line, 'reason': 'screened_out', 'fields': 'magnitude or catalogue bounds', 'key': key})
        for _, line in records[1:]:
            audit.append({'catalog': 'earthquake', 'line': line, 'reason': 'duplicate', 'fields': f'duplicate of line {first_line}', 'key': key})
    return result


def load_typhoons(path: Path, audit: list[dict] | None = None) -> tuple[list[dict], dict[str, list[dict]]]:
    audit = audit if audit is not None else []
    candidates: dict[tuple[str, datetime], list[tuple[dict, int]]] = {}
    points, groups = [], {}
    for line_number, row in enumerate(read_rows(path)[1:], 2):
        if len(row) < 17:
            audit.append({'catalog': 'typhoon', 'line': line_number, 'reason': 'invalid', 'fields': 'short row'})
            continue
        year, month, day, hour = map(number, row[0:4])
        number_id, lat, lon, wind_kt = number(row[4]), number(row[7]), number(row[8]), number(row[10])
        # The Japan typhoon catalogue stores 30KT long/short radii at columns
        # 15 and 16 (km).  The spatial criterion uses only the long radius.
        long_km, short_km = number(row[15]), number(row[16])
        missing = missing_required_fields([('track_time', year if None not in (year, month, day, hour) else None), ('typhoon_id', number_id), ('latitude', lat), ('longitude', lon), ('wind_speed', wind_kt), ('R30_long', long_km)])
        if missing:
            audit.append({'catalog': 'typhoon', 'line': line_number, 'reason': 'invalid', 'fields': ','.join(missing)})
            continue
        try:
            if any(value != int(value) for value in (year, month, day, hour, number_id)):
                raise ValueError('non-integer date or ID')
            moment = parse_ty_time(int(year), int(month), int(day), int(hour))
        except (ValueError, OverflowError):
            audit.append({'catalog': 'typhoon', 'line': line_number, 'reason': 'invalid', 'fields': 'track_time or typhoon_id'})
            continue
        sid = f"TY{int(year) % 100:02d}{int(number_id) % 100:02d}"
        point = {"sid": sid, "time": moment, "lat": lat, "lon": lon,
                 "wind_kt": wind_kt, "wind_ms": wind_kt * KNOT_TO_MS,
                 "r30_long": long_km, "r30_short": short_km,
                 # R30 spatial criterion: use the JMA 30KT long radius
                 # directly, without averaging with the short radius.
                 "r30": long_km}
        candidates.setdefault((sid, moment), []).append((point, line_number))
    for key, records in candidates.items():
        first, first_line = records[0]
        if any(item != first for item, _ in records[1:]):
            for _, line in records:
                audit.append({'catalog': 'typhoon', 'line': line, 'reason': 'conflict', 'fields': 'same ID and timestamp, different attributes; all excluded', 'key': f'{key[0]}|{iso(key[1])}'})
            continue
        if first['r30_long'] > 0 and (first['r30_short'] is None or first['r30_short'] >= 0) and first['wind_kt'] >= 34.0 and 5 <= first['lat'] <= 55 and 115 <= first['lon'] <= 180:
            points.append(first)
            groups.setdefault(first['sid'], []).append(first)
        else:
            audit.append({'catalog': 'typhoon', 'line': first_line, 'reason': 'screened_out', 'fields': 'R30, wind speed or catalogue bounds', 'key': f'{key[0]}|{iso(key[1])}'})
        for _, line in records[1:]:
            audit.append({'catalog': 'typhoon', 'line': line, 'reason': 'duplicate', 'fields': f'duplicate of line {first_line}', 'key': f'{key[0]}|{iso(key[1])}'})
    for track in groups.values():
        track.sort(key=lambda item: item["time"])
    return points, groups


def write_csv(path: Path, columns: list[str], rows: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns, lineterminator="\r\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({column: row.get(column, "") for column in columns})


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--earthquake-file", type=Path, required=True)
    parser.add_argument("--typhoon-file", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    audit: list[dict] = []
    earthquakes = load_earthquakes(args.earthquake_file, audit)
    points, groups = load_typhoons(args.typhoon_file, audit)
    earthquakes.sort(key=lambda item: item["time"])
    eq_times = [utc_timestamp(item["time"]) for item in earthquakes]
    best: dict[tuple[str, str], tuple[float, dict, dict]] = {}
    for point in points:
        point_ts = utc_timestamp(point["time"])
        left = bisect.bisect_left(eq_times, point_ts - WINDOW_HOURS * 3600)
        right = bisect.bisect_right(eq_times, point_ts + WINDOW_HOURS * 3600)
        for earthquake in earthquakes[left:right]:
            delta = abs((point["time"] - earthquake["time"]).total_seconds()) / 3600.0
            distance = distance_km(earthquake["lat"], earthquake["lon"], point["lat"], point["lon"])
            if distance > point["r30"]:
                continue
            key = (earthquake["id"], point["sid"])
            score = delta * 10000 + distance
            if key not in best or score < best[key][0]:
                best[key] = (score, earthquake, point)

    main_rows, selected = [], []
    # One typhoon event may be close to several earthquakes.  Keep exactly
    # one pair per typhoon, preferring the larger magnitude; for equal
    # magnitudes prefer the smallest time difference and then distance.
    one_per_typhoon: dict[str, tuple[tuple[float, float, float], dict, dict]] = {}
    for candidate in best.values():
        _, earthquake, point = candidate
        delta = abs((point["time"] - earthquake["time"]).total_seconds()) / 3600.0
        distance = distance_km(earthquake["lat"], earthquake["lon"], point["lat"], point["lon"])
        score = (-float(earthquake["mag"]), delta, distance)
        previous = one_per_typhoon.get(point["sid"])
        if previous is None:
            one_per_typhoon[point["sid"]] = (score, earthquake, point)
        else:
            previous_score, _, _ = previous
            if score < previous_score:
                one_per_typhoon[point["sid"]] = (score, earthquake, point)

    for _, earthquake, point in sorted(one_per_typhoon.values(), key=lambda item: item[1]["time"]):
        z_id = f"EQ-{earthquake['id']}__TC-{point['sid']}"
        distance = distance_km(earthquake["lat"], earthquake["lon"], point["lat"], point["lon"])
        main_rows.append({
            "z_id": z_id, "coupling_type": "Simultaneous", "eq_time": iso(earthquake["time"]),
            "eq_lat": f"{earthquake['lat']:.5f}", "eq_lon": f"{earthquake['lon']:.5f}",
            "Mw": f"{earthquake['mag']:.2f}", "depth_km": f"{earthquake['depth']:.1f}" if earthquake['depth'] is not None else "",
            "tc_time": iso(point["time"]), "tc_lat": f"{point['lat']:.5f}", "tc_lon": f"{point['lon']:.5f}",
            "wind_kt": f"{point['wind_kt']:.1f}", "wind_ms": f"{point['wind_ms']:.2f}",
            "dt_hours": f"{abs((point['time'] - earthquake['time']).total_seconds()) / 3600:.2f}",
            "distance_km": f"{distance:.2f}", "R30_km": f"{point['r30']:.2f}",
            "R30_long_km": f"{point['r30_long']:.2f}", "R30_short_km": f"{point['r30_short']:.2f}" if point['r30_short'] is not None else "",
        })
        selected.append((z_id, point["sid"]))

    track_rows = []
    for z_id, sid in selected:
        for point in groups[sid]:
            track_rows.append({
                "z_id": z_id, "coupling_type": "Simultaneous", "times": iso(point["time"]),
                "lats": f"{point['lat']:.5f}", "lons": f"{point['lon']:.5f}",
                "winds": f"{point['wind_ms']:.2f}", "winds_kt": f"{point['wind_kt']:.1f}",
            })
    write_csv(args.output_dir / "Coupling moment information.csv", MAIN_COLUMNS, main_rows)
    write_csv(args.output_dir / "Complete set of typhoon events satisfying coupling conditions.csv", TRACK_COLUMNS, track_rows)
    write_csv(args.output_dir / "event_data_quality_audit.csv", ['catalog', 'line', 'reason', 'fields', 'key'], audit)
    print(f"recognized={len(main_rows)} track_rows={len(track_rows)} earthquakes={len(earthquakes)} typhoon_points={len(points)}")


if __name__ == "__main__":
    main()
