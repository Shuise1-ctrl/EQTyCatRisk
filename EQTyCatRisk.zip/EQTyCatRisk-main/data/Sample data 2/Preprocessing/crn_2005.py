"""Paired 2005 case: common normal inputs, separate scenario evaluations."""
from pathlib import Path
import importlib.util
import json
import hashlib
import sys
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

ROOT=Path(__file__).resolve().parents[3]
spec=importlib.util.spec_from_file_location('eqty_mc_study',ROOT/'MC_Convergence_Study/run_mc_study.py')
study=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=study
spec.loader.exec_module(study)

def calculate_and_write(frame, model, sequence, mi, si, thresholds, args, case, output_dir, stem, rate, grid_file):
    frame['_source_row']=np.arange(len(frame),dtype=np.int64)
    works={name:study.build_working(frame,mode,model,sequence,mi,si,thresholds) for name,mode in [('Earthquake','earthquake'),('Typhoon','typhoon'),('Coupled','coupled')]}
    eq,cp=works['Earthquake'],works['Coupled']
    # Fail closed if differing selection would require a different pairing scheme.
    eq_idx=np.argsort(eq.el.to_numpy())[::-1][:min(len(eq),args.max_copula_grids)]
    cp_idx=np.argsort(cp.el.to_numpy())[::-1][:min(len(cp),args.max_copula_grids)]
    if not np.array_equal(eq_idx,cp_idx): raise ValueError('CRN selected exposure records differ; matching requires review')
    if works['Typhoon'].el.sum()!=0: raise ValueError('CRN mode currently supports only zero typhoon-only expected loss')
    c1=study.make_context(eq,args.max_copula_grids)
    c2=dict(c1)
    sel=cp.iloc[cp_idx]
    c2['alpha'],c2['beta']=study.beta_parameters(sel.md.to_numpy(),np.where(sel.sd.to_numpy()<1e-10,1e-4,sel.sd.to_numpy()))
    c2['values']=sel.tv.to_numpy()
    c2['expected_loss_oku']=float(cp.el.sum())/1e8
    remaining=np.argsort(cp.el.to_numpy())[::-1][len(cp_idx):] if len(cp_idx)<len(cp) else np.array([],dtype=int)
    c2['deterministic_loss']=float(cp.iloc[remaining].el.sum())
    rng=np.random.default_rng(args.seed)
    eqv=np.empty(args.samples); cpv=np.empty(args.samples)
    for start in range(0,args.samples,128):
        n=min(128,args.samples-start); z=rng.standard_normal((n,len(eq_idx)))
        eqv[start:start+n]=study.simulate_with_z(c1,z)
        cpv[start:start+n]=study.simulate_with_z(c2,z)
        print(f'[CRN] {start+n}/{args.samples}',flush=True)
    vals={'Earthquake':eqv,'Typhoon':np.zeros(args.samples),'Coupled':cpv}
    expected={k:float(w.el.sum())/1e6/rate for k,w in works.items()}
    maxloss=max(eqv.max(),cpv.max())*100/rate
    bins=np.linspace(0,max(maxloss,1e-8),101)
    stats={}
    for name,arr in vals.items():
        x=arr*100/rate; stats[name]={'sample_mean_million_usd':float(x.mean()),'model_expected_million_usd':expected[name]}
        csv=output_dir/f'{stem}_{name}_loss.csv'
        pd.DataFrame({'loss_oku':arr}).to_csv(csv,index=False,encoding='utf-8-sig')
        colors={'Earthquake':'#c43c3c','Typhoon':'#2874b5','Coupled':'#8650a4'}
        color=colors[name]
        plt.rcParams.update({'font.family':'serif','font.serif':['Times New Roman','DejaVu Serif'],'font.size':19,'axes.labelsize':21,'xtick.labelsize':19,'ytick.labelsize':19,'axes.linewidth':1.3,'figure.facecolor':'white','savefig.facecolor':'white'})
        fig,ax=plt.subplots(figsize=(8.5,5.6),layout='constrained')
        if name=='Typhoon':
            ax.vlines(0,0,1,color=color,linewidth=4,clip_on=False);ax.plot(0,1,'o',color=color,markersize=7,clip_on=False);ax.axvline(0,color=color,linestyle='--',linewidth=1.8);ax.set_ylim(0,1.18);ax.set_ylabel('Probability mass')
            handles=[Line2D([],[],color=color,marker='o',linewidth=2,label='Sample distribution'),Line2D([],[],color=color,linestyle='--',linewidth=1.8,label=f'Model expected loss: {expected[name]:.3f}')]
            ax.legend(handles=handles,loc='upper right',frameon=False,fontsize=17)
        else:
            ax.hist(x,bins=bins,density=True,color=color,alpha=.48,edgecolor='white',linewidth=.35,label='Sample distribution')
            ax.axvline(expected[name],color=color,linestyle='--',linewidth=2.3,label=f'Model expected loss: {expected[name]:.3f}')
            ax.set_ylabel('Probability density');ax.legend(loc='upper right',fontsize=17,frameon=False)
        ax.set_xlim(0,20);ax.set_xticks([0,5,10,15,20]);ax.set_xlabel('Total residential loss (million USD)');ax.spines[['top','right']].set_visible(False)
        png=output_dir/f'{stem}_{name}_loss.png';fig.savefig(png,dpi=180);plt.close(fig)
        if args.public_dir:
            import shutil
            args.public_dir.mkdir(parents=True,exist_ok=True);shutil.copy2(csv,args.public_dir/csv.name);shutil.copy2(png,args.public_dir/png.name)
    def file_hash(path):
        h=hashlib.sha256()
        with open(path,'rb') as stream:
            for block in iter(lambda:stream.read(1048576),b''): h.update(block)
        return h.hexdigest()
    manifest={'case':args.case,'name':case.get('name',stem),'loss_file_stem':stem,'exposure':'without_Other','samples':args.samples,'seed':args.seed,'sequence':sequence,'sampling_method':'CRN','max_copula_grids':args.max_copula_grids,'exchange_rate_jpy_per_usd':rate,'grid_file':str(grid_file),'exposure_file':str(args.exposure_file),'model_file':str(args.model_pickle),'input_sha256':{'grid':file_hash(grid_file),'exposure':file_hash(args.exposure_file),'model':file_hash(args.model_pickle),'vulnerability':file_hash(args.vulnerability_csv)},'statistics':stats,'outputs':[f'{stem}_{name}_loss.csv' for name in vals],'png_outputs':[f'{stem}_{name}_loss.png' for name in vals]}
    dest=output_dir/f'{stem}_manifest.json';dest.write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    if args.public_dir:
        import shutil
        shutil.copy2(dest,args.public_dir/dest.name)
    print(json.dumps({'ok':True,**manifest}),flush=True)
