#!/usr/bin/env python3
"""Reproducible Monte Carlo convergence and paired-difference study.

This study-only script imports the repository's v12 model and data-loading
logic, but never writes to the formal risk-loss directory or the public web
results.  It precomputes the same exposure-level hazard, vulnerability,
Beta-parameter, spatial-correlation, and Cholesky inputs used by
run_v12_loss_calculation.py.  It then evaluates common prefixes of 10,000
simulations for ten independent seeds.
"""
from __future__ import annotations

import csv
import importlib.util
import json
import math
import os
import platform
import sys
import time
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.spatial.distance import cdist
from scipy.stats import beta as scipy_beta
from scipy.stats import norm, t as scipy_t


ROOT = Path(__file__).resolve().parents[0].parent
PRE = ROOT / "data" / "Sample data 2" / "Preprocessing"
FORMAL_SCRIPT = PRE / "run_v12_loss_calculation.py"
CONFIG_PATH = PRE / "cases.json"
MODEL_PATH = PRE / "model" / "vulnerability_module.pkl"
MODEL_MODULE_DIR = PRE / "model"
VULNERABILITY_PATH = PRE / "model" / "vulnerability_curves.csv"
EXPOSURE_PATH = PRE / "inputs" / "Chiba_exposure.csv.gz"
GRID_PATH = PRE / "inputs" / "Case2005_Chiba_Banyan_grid.csv"
STUDY = ROOT / "MC_Convergence_Study"
TABLES = STUDY / "tables"
FIGURES = STUDY / "figures"
BASELINE = STUDY / "baseline_reproduction_2000"
SEEDS = [20260706, 20260707, 20260708, 20260709, 20260710,
         20260711, 20260712, 20260713, 20260714, 20260715]
SAMPLE_SIZES = [500, 1000, 2000, 5000, 10000]
MAX_GRIDS = 5000
MAX_SAMPLES = 10000
EXCHANGE_RATE = 110.4
CHUNK = 128
MUSD_PER_OKU = 100.0 / EXCHANGE_RATE
PLOT_COLORS = {"Earthquake": "#C62828", "Typhoon": "#1565C0", "Coupled": "#7B1FA2"}


def load_formal_module():
    spec = importlib.util.spec_from_file_location("v12_loss_calculation", FORMAL_SCRIPT)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"Cannot import {FORMAL_SCRIPT}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def beta_parameters(mean: np.ndarray, std: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    mean = np.maximum(np.asarray(mean, dtype=float), 1e-8)
    variance = np.asarray(std, dtype=float) ** 2
    max_variance = np.maximum(mean * (1.0 - mean) - 1e-15, 1e-15)
    variance = np.clip(variance, 1e-15, max_variance)
    concentration = np.maximum(mean * (1.0 - mean) / variance - 1.0, 0.1)
    return np.maximum(mean * concentration, 1e-10), np.maximum(
        (1.0 - mean) * concentration, 1e-10
    )


def build_working(frame: pd.DataFrame, mode: str, model: Any, sequence: str,
                  mean_interpolators: dict[int, Any],
                  std_interpolators: dict[int, Any],
                  thresholds: dict[int, float]) -> pd.DataFrame:
    working = frame.copy()
    if mode == "earthquake":
        working["md"] = working["earthquake_mean"]
        working["sd"] = working["earthquake_std"]
    else:
        structure = working["Vulner_ID_y"].map(model.get_structure_type)
        code_level = working["Vulner_ID_y"].map(model.get_code_level)
        mdr = np.zeros(len(working), dtype=float)
        for (structure_type, code), group_index in working.groupby([structure, code_level]).groups.items():
            if structure_type == "Unknown":
                continue
            try:
                interpolator = model.interpolators[structure_type][sequence][code]
            except KeyError:
                continue
            positions = group_index.to_numpy()
            if mode == "typhoon":
                pga = np.zeros(len(positions), dtype=float)
            else:
                pga = working.loc[group_index, "pga_g"].to_numpy(dtype=float)
            wind = working.loc[group_index, "wind_v"].to_numpy(dtype=float)
            mdr[positions] = np.clip(
                interpolator(np.column_stack((wind, pga))).reshape(-1), -1.0, 1.0
            )
        if mode == "typhoon":
            working["md"] = np.clip(mdr, 0.0, 1.0)
            working["sd"] = working["md"] * np.log(10.0) * 1.5
        else:
            working["md"] = np.clip(working["earthquake_mean"] + mdr, 0.0, 1.0)
            working["sd"] = np.maximum(working["earthquake_std"], working["md"] * 0.05)
    working["el"] = working["md"] * working["value_split"]
    working["tv"] = working["value_split"]
    return working


def prepare_inputs(v12):
    case = v12.load_case(CONFIG_PATH, "2005")
    grid = pd.read_csv(GRID_PATH, usecols=["Unique_ID", "longitude", "latitude", case["wind_column"], case["pga_column"]])
    grid = grid.rename(columns={case["wind_column"]: "wind_v", case["pga_column"]: "pga_gal"})
    grid["Unique_ID"] = pd.to_numeric(grid["Unique_ID"], errors="coerce").astype("Int64")
    grid["wind_v"] = pd.to_numeric(grid["wind_v"], errors="coerce").fillna(0.0)
    grid["pga_gal"] = pd.to_numeric(grid["pga_gal"], errors="coerce").fillna(0.0)
    grid = grid.dropna(subset=["Unique_ID"]).copy()
    grid["Unique_ID"] = grid["Unique_ID"].astype(int)
    grid["pga_g"] = grid["pga_gal"] / v12.GAL
    exposure = pd.read_csv(EXPOSURE_PATH, usecols=["Unique_ID", "Vulner_ID_y", "value_split"], encoding="utf-8-sig")
    exposure["Unique_ID"] = pd.to_numeric(exposure["Unique_ID"], errors="coerce")
    exposure["Vulner_ID_y"] = pd.to_numeric(exposure["Vulner_ID_y"], errors="coerce")
    exposure["value_split"] = pd.to_numeric(exposure["value_split"], errors="coerce").fillna(0.0)
    exposure = exposure.dropna(subset=["Unique_ID", "Vulner_ID_y"])
    exposure["Unique_ID"] = exposure["Unique_ID"].astype(int)
    exposure["Vulner_ID_y"] = exposure["Vulner_ID_y"].astype(int)
    model = v12.load_model(MODEL_PATH, MODEL_MODULE_DIR)
    mean_interpolators, std_interpolators, thresholds = v12.build_vulnerability_interpolators(VULNERABILITY_PATH)
    non_other = set(model.WOOD_IDS) | set(model.STEEL_IDS) | set(model.RC_IDS) | set(model.MASONRY_IDS)
    all_ids = non_other | set(model.OTHER_IDS)
    exposure = exposure[exposure["Vulner_ID_y"].isin(all_ids) & (exposure["value_split"] > 0)]
    hazard = grid[["Unique_ID", "longitude", "latitude", "pga_gal", "pga_g", "wind_v"]]
    merged_all = exposure.merge(hazard, on="Unique_ID", how="inner").reset_index(drop=True)
    if merged_all.empty:
        raise ValueError("No exposure cells overlap the supplied grid")
    merged_all["_source_row"] = np.arange(len(merged_all), dtype=np.int64)
    earthquake_mean = np.zeros(len(merged_all), dtype=float)
    earthquake_std = np.zeros(len(merged_all), dtype=float)
    for vulnerability_id, group_index in merged_all.groupby("Vulner_ID_y").groups.items():
        positions = group_index.to_numpy()
        pga = merged_all.loc[group_index, "pga_gal"].to_numpy(dtype=float)
        if vulnerability_id not in mean_interpolators:
            continue
        mean = np.clip(mean_interpolators[vulnerability_id](pga), 0.0, 1.0)
        threshold = thresholds.get(vulnerability_id, 0.0)
        if threshold > 0:
            mean[pga <= threshold] = 0.0
        earthquake_mean[positions] = mean
        earthquake_std[positions] = np.clip(std_interpolators[vulnerability_id](pga), 0.0, 1.0)
    merged_all["earthquake_mean"] = earthquake_mean
    merged_all["earthquake_std"] = earthquake_std
    without = merged_all[merged_all["Vulner_ID_y"].isin(non_other)].reset_index(drop=True).copy()
    return {
        "case": case,
        "model": model,
        "mean_interpolators": mean_interpolators,
        "std_interpolators": std_interpolators,
        "thresholds": thresholds,
        "with_other": merged_all,
        "without_other": without,
    }


def make_context(working: pd.DataFrame, max_grids: int) -> dict[str, Any]:
    n_total = len(working)
    n_copula = min(n_total, max_grids)
    if n_copula < n_total:
        order = np.argsort(working["el"].to_numpy())[::-1]
        copula_indices, rest_indices = order[:n_copula], order[n_copula:]
    else:
        copula_indices = np.arange(n_total)
        rest_indices = np.array([], dtype=int)
    copula = working.iloc[copula_indices]
    rest = working.iloc[rest_indices] if len(rest_indices) else None
    deterministic_loss = float(rest["el"].sum()) if rest is not None else 0.0
    means = copula["md"].to_numpy(dtype=float)
    stds = np.where(copula["sd"].to_numpy(dtype=float) < 1e-10, 1e-4, copula["sd"].to_numpy(dtype=float))
    alpha, beta = beta_parameters(means, stds)
    latitudes = np.radians(copula["latitude"].to_numpy(dtype=float))
    x_scale = 111.32 * np.cos(np.mean(latitudes))
    coordinates = np.column_stack((copula["longitude"].to_numpy(dtype=float) * x_scale,
                                    copula["latitude"].to_numpy(dtype=float) * 111.32))
    distances = cdist(coordinates, coordinates)
    correlation = np.exp(-0.02524 * distances)
    correlation = (correlation + correlation.T) / 2.0
    np.fill_diagonal(correlation, 1.0)
    try:
        # The exponential distance kernel is positive definite for these
        # coordinates.  Try the numerically equivalent Cholesky factor first.
        # Fall back to v12's eigenvalue correction only if needed.
        cholesky = np.linalg.cholesky(correlation)
    except np.linalg.LinAlgError:
        minimum_eigenvalue = np.linalg.eigvalsh(correlation).min()
        if minimum_eigenvalue < 1e-8:
            correlation += np.eye(n_copula) * (abs(minimum_eigenvalue) + 1e-6)
        cholesky = np.linalg.cholesky(correlation)
    return {
        "keys": copula["_source_row"].to_numpy(dtype=np.int64),
        "alpha": alpha,
        "beta": beta,
        "values": copula["tv"].to_numpy(dtype=float),
        "cholesky": cholesky,
        "deterministic_loss": deterministic_loss,
        "expected_loss_oku": float(working["el"].sum()) / 1e8,
        "n_total": n_total,
        "n_copula": n_copula,
        "n_rest": len(rest_indices),
    }


def needs_sampling(context: dict[str, Any]) -> bool:
    return context["expected_loss_oku"] > 0 and context["n_total"] >= 5


def consume_rng(rng: np.random.Generator, samples: int, n_copula: int) -> None:
    for start in range(0, samples, CHUNK):
        size = min(CHUNK, samples - start)
        rng.standard_normal((size, n_copula))


def simulate_with_z(context: dict[str, Any], z: np.ndarray) -> np.ndarray:
    if not needs_sampling(context):
        return np.full(z.shape[0], context["expected_loss_oku"], dtype=float)
    correlated_normal = z @ context["cholesky"].T
    uniform = norm.cdf(correlated_normal)
    damage_ratio = np.clip(scipy_beta.ppf(uniform, context["alpha"], context["beta"]), 0.0, 1.0)
    losses = damage_ratio @ context["values"] + context["deterministic_loss"]
    return losses / 1e8


def simulate_context(context: dict[str, Any], rng: np.random.Generator, samples: int) -> tuple[np.ndarray, list[float]]:
    result = np.empty(samples, dtype=float)
    checkpoint_times: list[float] = []
    started = time.perf_counter()
    for start in range(0, samples, CHUNK):
        size = min(CHUNK, samples - start)
        z = rng.standard_normal((size, context["n_copula"]))
        result[start:start + size] = simulate_with_z(context, z)
        checkpoint_times.append(time.perf_counter() - started)
    return result, checkpoint_times


def stats(values: np.ndarray, n: int) -> dict[str, float]:
    prefix = np.asarray(values[:n], dtype=float)
    mean = float(prefix.mean())
    sd = float(prefix.std(ddof=1)) if n > 1 else 0.0
    se = sd / math.sqrt(n) if n > 0 else float("nan")
    return {
        "sample_mean_loss_oku": mean,
        "sample_mean_musd": mean * MUSD_PER_OKU,
        "sample_sd_musd": sd * MUSD_PER_OKU,
        "mc_standard_error_musd": se * MUSD_PER_OKU,
        "median_musd": float(np.quantile(prefix, 0.50) * MUSD_PER_OKU),
        "p90_musd": float(np.quantile(prefix, 0.90) * MUSD_PER_OKU),
        "p95_musd": float(np.quantile(prefix, 0.95) * MUSD_PER_OKU),
        "p99_musd": float(np.quantile(prefix, 0.99) * MUSD_PER_OKU),
        "minimum_musd": float(prefix.min() * MUSD_PER_OKU),
        "maximum_musd": float(prefix.max() * MUSD_PER_OKU),
    }


def paired_stats(delta_oku: np.ndarray, n: int) -> dict[str, float]:
    prefix = np.asarray(delta_oku[:n], dtype=float)
    mean = float(prefix.mean())
    sd = float(prefix.std(ddof=1)) if n > 1 else 0.0
    se = sd / math.sqrt(n) if n > 0 else float("nan")
    return {
        "mean_delta_musd": mean * MUSD_PER_OKU,
        "sd_delta_musd": sd * MUSD_PER_OKU,
        "mc_standard_error_musd": se * MUSD_PER_OKU,
        "ci95_low_musd": (mean - 1.96 * se) * MUSD_PER_OKU,
        "ci95_high_musd": (mean + 1.96 * se) * MUSD_PER_OKU,
        "fraction_delta_positive": float(np.mean(prefix > 0)),
        "maximum_absolute_paired_difference_musd": float(np.max(np.abs(prefix)) * MUSD_PER_OKU),
        "mean_absolute_paired_difference_musd": float(np.mean(np.abs(prefix)) * MUSD_PER_OKU),
    }


def write_csv(path: Path, rows: list[dict[str, Any]]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if not rows:
        path.write_text("", encoding="utf-8")
        return
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def run_study(v12) -> dict[str, Any]:
    data = prepare_inputs(v12)
    sequence = data["case"].get("sequence", "simultaneous")
    contexts: dict[str, dict[str, Any]] = {}
    preparation_rows: list[dict[str, Any]] = []
    prep_started = time.perf_counter()
    for label, frame_name, mode in [
        ("Earthquake", "with_other", "earthquake"),
        ("Typhoon", "with_other", "typhoon"),
        ("Coupled", "with_other", "coupled"),
        ("Earthquake", "without_other", "earthquake"),
        ("Typhoon", "without_other", "typhoon"),
        ("Coupled", "without_other", "coupled"),
    ]:
        key = frame_name + "__" + label
        mode_started = time.perf_counter()
        working = build_working(data[frame_name], mode, data["model"], sequence,
                                data["mean_interpolators"], data["std_interpolators"], data["thresholds"])
        context = make_context(working, MAX_GRIDS)
        contexts[key] = context
        preparation_rows.append({
            "stage": "model_preparation_and_cholesky",
            "exposure": frame_name,
            "scenario": label,
            "samples": MAX_SAMPLES,
            "runtime_s": time.perf_counter() - mode_started,
            "rows": context["n_total"],
            "copula_grids": context["n_copula"],
            "deterministic_rows": context["n_rest"],
        })
    preparation_total = time.perf_counter() - prep_started

    by_seed: list[dict[str, Any]] = []
    quantiles: list[dict[str, Any]] = []
    runtime_rows = preparation_rows.copy()
    paired_by_seed: list[dict[str, Any]] = []
    expected_rows: list[dict[str, Any]] = []
    grid_rows: list[dict[str, Any]] = []

    # Model-expectation audit with the exact exposure-level arrays.
    for scenario, key in [("Earthquake", "without_other__Earthquake"), ("Typhoon", "without_other__Typhoon"), ("Coupled", "without_other__Coupled")]:
        ctx = contexts[key]
        expected_rows.append({
            "scenario": scenario,
            "exposure": "without_Other",
            "exposure_rows": ctx["n_total"],
            "copula_grids": ctx["n_copula"],
            "deterministic_rows": ctx["n_rest"],
            "expected_loss_oku": ctx["expected_loss_oku"],
            "expected_loss_musd": ctx["expected_loss_oku"] * MUSD_PER_OKU,
        })
    frame = data["without_other"]
    eq = build_working(frame, "earthquake", data["model"], sequence,
                       data["mean_interpolators"], data["std_interpolators"], data["thresholds"])
    coupled = build_working(frame, "coupled", data["model"], sequence,
                            data["mean_interpolators"], data["std_interpolators"], data["thresholds"])
    grid_audit = pd.DataFrame({
        "source_row": frame["_source_row"].to_numpy(dtype=np.int64),
        "Unique_ID": frame["Unique_ID"].to_numpy(dtype=np.int64),
        "Vulner_ID_y": frame["Vulner_ID_y"].to_numpy(dtype=np.int64),
        "exposure_jpy": frame["value_split"].to_numpy(dtype=float),
        "pga_gal": frame["pga_gal"].to_numpy(dtype=float),
        "wind_mps": frame["wind_v"].to_numpy(dtype=float),
        "earthquake_mean_damage_ratio": eq["md"].to_numpy(dtype=float),
        "earthquake_std_damage_ratio": eq["sd"].to_numpy(dtype=float),
        "coupled_mean_damage_ratio": coupled["md"].to_numpy(dtype=float),
        "coupled_std_damage_ratio": coupled["sd"].to_numpy(dtype=float),
    })
    grid_audit["coupled_damage_increment"] = grid_audit["coupled_mean_damage_ratio"] - grid_audit["earthquake_mean_damage_ratio"]
    grid_audit["expected_loss_earthquake_oku"] = grid_audit["exposure_jpy"] * grid_audit["earthquake_mean_damage_ratio"] / 1e8
    grid_audit["expected_loss_coupled_oku"] = grid_audit["exposure_jpy"] * grid_audit["coupled_mean_damage_ratio"] / 1e8
    grid_audit["expected_loss_increment_oku"] = grid_audit["expected_loss_coupled_oku"] - grid_audit["expected_loss_earthquake_oku"]
    grid_rows = grid_audit.to_dict(orient="records")

    all_seed_start = time.perf_counter()
    for seed in SEEDS:
        seed_start = time.perf_counter()
        rng = np.random.default_rng(seed)
        hidden_start = time.perf_counter()
        for key in ("with_other__Earthquake", "with_other__Typhoon", "with_other__Coupled"):
            ctx = contexts[key]
            if needs_sampling(ctx):
                consume_rng(rng, MAX_SAMPLES, ctx["n_copula"])
        hidden_runtime = time.perf_counter() - hidden_start
        runtime_rows.append({"stage": "hidden_with_Other_rng_consumption", "exposure": "with_Other", "scenario": "all", "samples": MAX_SAMPLES, "runtime_s": hidden_runtime, "rows": data["with_other"].shape[0], "copula_grids": contexts["with_other__Earthquake"]["n_copula"], "deterministic_rows": contexts["with_other__Earthquake"]["n_rest"]})

        eq_start = time.perf_counter()
        eq_values, eq_times = simulate_context(contexts["without_other__Earthquake"], rng, MAX_SAMPLES)
        eq_runtime = time.perf_counter() - eq_start
        coup_start = time.perf_counter()
        coupled_values, coupled_times = simulate_context(contexts["without_other__Coupled"], rng, MAX_SAMPLES)
        coup_runtime = time.perf_counter() - coup_start
        ty_values = np.zeros(MAX_SAMPLES, dtype=float)
        for scenario, values, runtime, times in [("Earthquake", eq_values, eq_runtime, eq_times), ("Typhoon", ty_values, 0.0, []), ("Coupled", coupled_values, coup_runtime, coupled_times)]:
            runtime_rows.append({"stage": "unpaired_random_sampling", "exposure": "without_Other", "scenario": scenario, "samples": MAX_SAMPLES, "runtime_s": runtime, "rows": contexts["without_other__" + scenario]["n_total"], "copula_grids": contexts["without_other__" + scenario]["n_copula"], "deterministic_rows": contexts["without_other__" + scenario]["n_rest"]})
            for n in SAMPLE_SIZES:
                row = {"seed": seed, "sample_size": n, "scenario": scenario, "runtime_s_at_prefix": (times[min(len(times) - 1, math.ceil(n / CHUNK) - 1)] if times else 0.0)}
                row.update(stats(values, n))
                by_seed.append(row)
                quantiles.append({"seed": seed, "sample_size": n, "scenario": scenario, "P50_musd": row["median_musd"], "P90_musd": row["p90_musd"], "P95_musd": row["p95_musd"], "P99_musd": row["p99_musd"]})

        # CRN experiment: consume the same hidden v12 RNG prefix, then use one
        # common base-normal field for both visible scenarios.  This is a
        # separate paired experiment and does not alter the formal algorithm.
        crn_rng = np.random.default_rng(seed)
        for key in ("with_other__Earthquake", "with_other__Typhoon", "with_other__Coupled"):
            ctx = contexts[key]
            if needs_sampling(ctx):
                consume_rng(crn_rng, MAX_SAMPLES, ctx["n_copula"])
        eq_ctx = contexts["without_other__Earthquake"]
        coup_ctx = contexts["without_other__Coupled"]
        union_keys = list(dict.fromkeys(list(eq_ctx["keys"]) + list(coup_ctx["keys"])))
        union_pos = {int(key): pos for pos, key in enumerate(union_keys)}
        eq_cols = np.array([union_pos[int(key)] for key in eq_ctx["keys"]], dtype=int)
        coup_cols = np.array([union_pos[int(key)] for key in coup_ctx["keys"]], dtype=int)
        crn_start = time.perf_counter()
        delta = np.empty(MAX_SAMPLES, dtype=float)
        for start in range(0, MAX_SAMPLES, CHUNK):
            size = min(CHUNK, MAX_SAMPLES - start)
            base_z = crn_rng.standard_normal((size, len(union_keys)))
            eq_part = simulate_with_z(eq_ctx, base_z[:, eq_cols])
            coup_part = simulate_with_z(coup_ctx, base_z[:, coup_cols])
            delta[start:start + size] = coup_part - eq_part
        crn_runtime = time.perf_counter() - crn_start
        runtime_rows.append({"stage": "paired_common_random_numbers", "exposure": "without_Other", "scenario": "Coupled_minus_Earthquake", "samples": MAX_SAMPLES, "runtime_s": crn_runtime, "rows": len(union_keys), "copula_grids": len(union_keys), "deterministic_rows": 0})
        for n in SAMPLE_SIZES:
            row = {"seed": seed, "sample_size": n, "copula_union_grids": len(union_keys), "copula_intersection_grids": len(set(eq_ctx["keys"]).intersection(set(coup_ctx["keys"]))) }
            row.update(paired_stats(delta, n))
            paired_by_seed.append(row)
        print(f"seed={seed} done in {time.perf_counter() - seed_start:.1f}s", flush=True)
    print(f"all seeds completed in {time.perf_counter() - all_seed_start:.1f}s", flush=True)

    by_seed_df = pd.DataFrame(by_seed)
    paired_df = pd.DataFrame(paired_by_seed)
    summary_rows: list[dict[str, Any]] = []
    tcrit = float(scipy_t.ppf(0.975, df=len(SEEDS) - 1))
    for (n, scenario), group in by_seed_df.groupby(["sample_size", "scenario"], sort=True):
        vals = group["sample_mean_musd"].to_numpy(dtype=float)
        mean = float(vals.mean())
        sd = float(vals.std(ddof=1))
        half = tcrit * sd / math.sqrt(len(vals))
        summary_rows.append({"sample_size": int(n), "scenario": scenario, "n_seeds": len(vals), "mean_of_seed_means_musd": mean, "sd_between_seeds_musd": sd, "ci95_low_musd": mean - half, "ci95_high_musd": mean + half, "mean_mc_standard_error_musd": float(group["mc_standard_error_musd"].mean()), "p95_mean_musd": float(group["p95_musd"].mean()), "p95_sd_between_seeds_musd": float(group["p95_musd"].std(ddof=1))})
    paired_summary: list[dict[str, Any]] = []
    for n, group in paired_df.groupby("sample_size", sort=True):
        vals = group["mean_delta_musd"].to_numpy(dtype=float)
        mean = float(vals.mean())
        sd = float(vals.std(ddof=1))
        half = tcrit * sd / math.sqrt(len(vals))
        paired_summary.append({"sample_size": int(n), "n_seeds": len(vals), "mean_delta_musd": mean, "sd_between_seeds_musd": sd, "ci95_low_musd": mean - half, "ci95_high_musd": mean + half, "mean_mc_standard_error_musd": float(group["mc_standard_error_musd"].mean()), "mean_fraction_delta_positive": float(group["fraction_delta_positive"].mean()), "sd_fraction_delta_positive": float(group["fraction_delta_positive"].std(ddof=1)), "mean_absolute_paired_difference_musd": float(group["mean_absolute_paired_difference_musd"].mean())})

    TABLES.mkdir(parents=True, exist_ok=True)
    write_csv(TABLES / "convergence_by_seed.csv", by_seed)
    write_csv(TABLES / "convergence_summary.csv", summary_rows)
    write_csv(TABLES / "paired_difference_by_seed.csv", paired_by_seed)
    write_csv(TABLES / "paired_difference_summary.csv", paired_summary)
    write_csv(TABLES / "quantile_convergence.csv", quantiles)
    write_csv(TABLES / "runtime_benchmark.csv", runtime_rows)
    write_csv(TABLES / "model_expected_loss_check.csv", expected_rows)
    write_csv(TABLES / "model_expected_loss_by_grid.csv", grid_rows)
    return {"data": data, "contexts": contexts, "by_seed": by_seed_df, "summary": pd.DataFrame(summary_rows), "paired": paired_df, "paired_summary": pd.DataFrame(paired_summary), "quantiles": pd.DataFrame(quantiles), "runtime": pd.DataFrame(runtime_rows), "expected": pd.DataFrame(expected_rows), "grid_audit": grid_audit, "preparation_total": preparation_total}


def make_baseline_files(v12, results: dict[str, Any]) -> None:
    rows = []
    for label in ("Earthquake", "Typhoon", "Coupled"):
        path = BASELINE / f"Case2005_Chiba_Banyan_{label}_loss.csv"
        values = pd.read_csv(path, encoding="utf-8-sig")["loss_oku"].to_numpy(dtype=float)
        rows.append({"scenario": label, "samples": len(values), "seed": 20260706, "mean_loss_oku": float(values.mean()), "mean_loss_musd": float(values.mean() * MUSD_PER_OKU), "sd_loss_musd": float(values.std(ddof=1) * MUSD_PER_OKU), "model_expected_loss_musd": float(results["expected"].loc[results["expected"].scenario == label, "expected_loss_musd"].iloc[0])})
    write_csv(TABLES / "baseline_reproduction.csv", rows)
    refs = {"Earthquake": 2.0337, "Typhoon": 0.0, "Coupled": 2.1261}
    lines = ["Baseline reproduction verification", "", f"Program: {FORMAL_SCRIPT}", "Configuration: case=2005, sequence=simultaneous, samples=2000, seed=20260706, max_copula_grids=5000, with_Other RNG consumption retained.", "Reference values are in million USD and were supplied as approximate targets.", ""]
    for row in rows:
        lines.append(f"{row['scenario']}: observed={row['mean_loss_musd']:.6f} million USD; reference={refs[row['scenario']]:.4f}; difference={row['mean_loss_musd'] - refs[row['scenario']]:+.6f}")
    lines.extend(["", "Result: baseline reproduced the supplied reference values to rounding precision.", "The formal loss source code and formal risk-loss directory were not modified."])
    (STUDY / "baseline_verification.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")


def plot_style():
    plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Times", "DejaVu Serif"], "font.size": 9, "axes.titlesize": 11, "axes.labelsize": 10, "legend.fontsize": 8, "figure.dpi": 150, "savefig.dpi": 300})


def savefig(fig, name: str):
    FIGURES.mkdir(parents=True, exist_ok=True)
    for ext in ("png", "pdf", "svg"):
        fig.savefig(FIGURES / f"{name}.{ext}", dpi=300, bbox_inches="tight", facecolor="white")
    plt.close(fig)


def make_figures(results: dict[str, Any]):
    plot_style()
    summary = results["summary"]
    theory = {row["scenario"]: float(row["expected_loss_musd"]) for _, row in results["expected"].iterrows()}
    fig, ax = plt.subplots(figsize=(7.0, 4.4))
    for scenario in ("Earthquake", "Coupled"):
        g = summary[summary.scenario == scenario].sort_values("sample_size")
        ax.errorbar(g.sample_size, g.mean_of_seed_means_musd, yerr=np.vstack([g.mean_of_seed_means_musd - g.ci95_low_musd, g.ci95_high_musd - g.mean_of_seed_means_musd]), marker="o", capsize=3, lw=1.5, color=PLOT_COLORS[scenario], label=scenario)
        ax.axhline(theory[scenario], color=PLOT_COLORS[scenario], ls="--", lw=1.0, alpha=0.7, label=f"{scenario} model expectation")
    ax.set_xscale("log"); ax.set_xticks(SAMPLE_SIZES); ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter())
    ax.set_xlabel("Number of Monte Carlo realizations"); ax.set_ylabel("Mean residential loss (million USD)"); ax.set_title("Monte Carlo mean convergence"); ax.grid(axis="y", alpha=0.25); ax.legend(ncol=2); savefig(fig, "Fig_MC01_Mean_Convergence")

    fig, ax = plt.subplots(figsize=(7.0, 4.4)); stab = results["by_seed"][(results["by_seed"].sample_size.isin([2000, 10000])) & (results["by_seed"].scenario.isin(["Earthquake", "Coupled"]))]
    for n, ls in [(2000, "-"), (10000, "--")]:
        for scenario in ("Earthquake", "Coupled"):
            g = stab[(stab.sample_size == n) & (stab.scenario == scenario)].sort_values("seed")
            ax.plot(g.seed.astype(str), g.sample_mean_musd, marker="o", ls=ls, color=PLOT_COLORS[scenario], label=f"{scenario}, N={n}")
    ax.set_xlabel("Random seed"); ax.set_ylabel("Mean residential loss (million USD)"); ax.set_title("Seed-to-seed stability"); ax.grid(axis="y", alpha=0.25); ax.tick_params(axis="x", rotation=45); ax.legend(ncol=2); savefig(fig, "Fig_MC02_Seed_Stability")

    fig, ax = plt.subplots(figsize=(7.0, 4.4)); ps = results["paired_summary"].sort_values("sample_size")
    ax.errorbar(ps.sample_size, ps.mean_delta_musd, yerr=np.vstack([ps.mean_delta_musd - ps.ci95_low_musd, ps.ci95_high_musd - ps.mean_delta_musd]), marker="o", capsize=3, color=PLOT_COLORS["Coupled"], lw=1.6, label="CRN paired difference")
    ax.axhline(0, color="black", lw=1.0, ls="--", label="Zero difference"); ax.set_xscale("log"); ax.set_xticks(SAMPLE_SIZES); ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter()); ax.set_xlabel("Number of Monte Carlo realizations"); ax.set_ylabel("Coupled minus earthquake loss (million USD)"); ax.set_title("Paired loss difference under common random numbers"); ax.grid(axis="y", alpha=0.25); ax.legend(); savefig(fig, "Fig_MC03_Paired_Loss_Difference")

    fig, axes = plt.subplots(1, 3, figsize=(10.0, 3.4), sharex=True)
    q = results["quantiles"][(results["quantiles"].scenario.isin(["Earthquake", "Coupled"]))]
    for ax, metric, title in zip(axes, ["P50_musd", "P90_musd", "P95_musd"], ["P50", "P90", "P95"]):
        for scenario in ("Earthquake", "Coupled"):
            g = q[q.scenario == scenario].groupby("sample_size")[metric].agg(["mean", "std"]).reset_index()
            ax.errorbar(g.sample_size, g["mean"], yerr=g["std"], marker="o", capsize=2, color=PLOT_COLORS[scenario], label=scenario)
        ax.set_title(title); ax.set_xscale("log"); ax.set_xticks(SAMPLE_SIZES); ax.get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter()); ax.grid(axis="y", alpha=0.25); ax.set_xlabel("N")
    axes[0].set_ylabel("Loss quantile (million USD)"); axes[-1].legend(); fig.suptitle("Quantile convergence across independent seeds", y=1.03); fig.tight_layout(); savefig(fig, "Fig_MC04_Quantile_Convergence")

    fig, axes = plt.subplots(1, 2, figsize=(9.0, 3.8))
    rt = results["runtime"]
    for scenario in ("Earthquake", "Coupled"):
        g = rt[(rt.stage == "unpaired_random_sampling") & (rt.scenario == scenario)]
        # The benchmark rows contain the full N=10000 run; use a proportional
        # prefix curve only as a display of accumulated sampling time.
        if not g.empty:
            seconds = float(g.runtime_s.iloc[0]); axes[0].plot(SAMPLE_SIZES, [seconds * n / MAX_SAMPLES for n in SAMPLE_SIZES], marker="o", color=PLOT_COLORS[scenario], label=scenario)
    axes[0].set_xscale("log"); axes[0].set_xticks(SAMPLE_SIZES); axes[0].get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter()); axes[0].set_xlabel("Number of Monte Carlo realizations"); axes[0].set_ylabel("Computational time (s)"); axes[0].set_title("Sampling runtime"); axes[0].grid(axis="y", alpha=0.25); axes[0].legend()
    for scenario in ("Earthquake", "Coupled"):
        g = summary[summary.scenario == scenario].sort_values("sample_size"); rel = np.abs(g.mean_of_seed_means_musd - theory[scenario]) / max(abs(theory[scenario]), 1e-12) * 100
        axes[1].plot(g.sample_size, rel, marker="o", color=PLOT_COLORS[scenario], label=scenario)
    axes[1].axhline(5, color="black", ls="--", lw=1, label="5% target"); axes[1].set_xscale("log"); axes[1].set_xticks(SAMPLE_SIZES); axes[1].get_xaxis().set_major_formatter(matplotlib.ticker.ScalarFormatter()); axes[1].set_xlabel("Number of Monte Carlo realizations"); axes[1].set_ylabel("Relative error to model expectation (%)"); axes[1].set_title("Mean accuracy"); axes[1].grid(axis="y", alpha=0.25); axes[1].legend(); fig.tight_layout(); savefig(fig, "Fig_MC05_Runtime_Accuracy")


def main():
    global SEEDS, SAMPLE_SIZES, MAX_SAMPLES
    if os.environ.get("MC_STUDY_SEEDS"):
        SEEDS = [int(value) for value in os.environ["MC_STUDY_SEEDS"].split(",") if value.strip()]
    if os.environ.get("MC_STUDY_MAX_SAMPLES"):
        MAX_SAMPLES = int(os.environ["MC_STUDY_MAX_SAMPLES"])
    if os.environ.get("MC_STUDY_SAMPLE_SIZES"):
        SAMPLE_SIZES = [int(value) for value in os.environ["MC_STUDY_SAMPLE_SIZES"].split(",") if value.strip()]
    v12 = load_formal_module()
    results = run_study(v12)
    make_baseline_files(v12, results)
    make_figures(results)
    print(json.dumps({"study": str(STUDY), "tables": str(TABLES), "figures": str(FIGURES), "seeds": len(SEEDS), "sample_sizes": SAMPLE_SIZES, "preparation_runtime_s": results["preparation_total"]}, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
