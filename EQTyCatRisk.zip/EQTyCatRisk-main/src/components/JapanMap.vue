<script setup lang="ts">
import { nextTick, onMounted, onUnmounted, ref, watch } from 'vue'
import L from 'leaflet'
import 'leaflet/dist/leaflet.css'
import type { CouplingCatalogItem, CouplingEvent, RiskGridCell } from '../types'
import { JAPAN_MAP_CENTER, JAPAN_MAP_ZOOM, JAPAN_VIEW_BOUNDS } from '../data/prefectures'
import { addEpicenterLayers } from '../utils/epicenterMarker'
import { typhoonCodeFromZid } from '../utils/pairLabel'
import { catalogItemToMapEvent } from '../utils/generator'
import {
  addGridLossLayer,
  GRID_HEAT_METRICS,
  gridHeatMetricLabel,
  type GridHeatMetric,
} from '../utils/gridLossLayer'
import { formatCouplingType } from '../utils/formatters'
import { addPathDirectionArrows } from '../utils/pathArrows'

const props = defineProps<{
  /** （ / ） */
  event?: CouplingEvent | null
  /** ： */
  events?: CouplingCatalogItem[]
  selectedId?: string
  /**  JPY（） */
  lossGrids?: RiskGridCell[]
  gridHalfDeg?: number
  heatMetric?: GridHeatMetric
}>()

const emit = defineEmits<{
  select: [id: string]
  'update:heatMetric': [metric: GridHeatMetric]
}>()

const mapContainer = ref<HTMLElement | null>(null)
let map: L.Map | null = null
let overviewLayer: L.LayerGroup | null = null
let selectedLayer: L.LayerGroup | null = null
let lossLayer: L.LayerGroup | null = null
let resizeObserver: ResizeObserver | null = null
let didFitAll = false
let didFitLoss = false

/** English-label basemap first, with global fallbacks that need no API key. */
const TILE_SOURCES = [
  {
    name: 'Esri World Street Map',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}',
    options: {
      maxZoom: 19,
    },
    credit: '© Esri · English labels',
  },
  {
    name: 'Esri',
    url: 'https://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/tile/{z}/{y}/{x}',
    options: {
      maxZoom: 19,
    },
    credit: '© Esri',
  },
  {
    name: 'OSM',
    url: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
    options: {
      maxZoom: 19,
    },
    credit: '© OpenStreetMap',
  },
]

const activeTileCredit = ref(TILE_SOURCES[0]!.credit)

function addTileLayer(targetMap: L.Map) {
  let sourceIndex = 0
  let currentLayer: L.TileLayer | null = null
  let errorCount = 0

  const trySource = (index: number) => {
    if (index >= TILE_SOURCES.length) return
    const source = TILE_SOURCES[index]!
    sourceIndex = index
    errorCount = 0
    activeTileCredit.value = source.credit

    if (currentLayer) {
      targetMap.removeLayer(currentLayer)
      currentLayer = null
    }

    const layer = L.tileLayer(source.url, {
      ...source.options,
      attribution: '',
    })

    layer.on('tileerror', () => {
      errorCount += 1
      // ，
      if (errorCount >= 4 && sourceIndex === index) {
        trySource(index + 1)
      }
    })

    layer.on('load', () => {
      errorCount = 0
    })

    layer.addTo(targetMap)
    currentLayer = layer
  }

  trySource(0)
}

function initMap() {
  if (!mapContainer.value || map) return

  map = L.map(mapContainer.value, {
    center: JAPAN_MAP_CENTER,
    zoom: JAPAN_MAP_ZOOM,
    scrollWheelZoom: true,
    preferCanvas: true,
    attributionControl: false,
    zoomControl: true,
  })

  addTileLayer(map)
  lossLayer = L.layerGroup().addTo(map)
  overviewLayer = L.layerGroup().addTo(map)
  selectedLayer = L.layerGroup().addTo(map)
  renderAll()

  requestAnimationFrame(() => map?.invalidateSize())
}

function selectPair(id: string) {
  emit('select', id)
}

function drawOverviewPath(item: CouplingCatalogItem, layer: L.LayerGroup, muted: boolean) {
  const coords = item.typhoonPath.map((p) => [p.lat, p.lng] as [number, number])
  if (coords.length < 2) return

  const color = muted ? '#94a3b8' : '#0ea5a4'
  const line = L.polyline(coords, {
    color,
    weight: muted ? 1.2 : 2.2,
    opacity: muted ? 0.28 : 0.55,
    interactive: true,
  })

  line.bindTooltip(
    `Typhoon ${typhoonCodeFromZid(item.id)} · Coupled Mj ${item.magnitude.toFixed(1)} · ${formatCouplingType(item.couplingType)}`,
    { sticky: true, opacity: 0.92 },
  )
  line.on('click', () => selectPair(item.id))
  line.addTo(layer)

  // ： → ；
  addPathDirectionArrows(coords, layer, {
    color: muted ? '#64748b' : '#0d9488',
    every: Math.max(1, Math.floor(coords.length / 2)),
    maxArrows: 1,
    size: muted ? 16 : 20,
    opacity: muted ? 0.7 : 1,
  })
}

function drawSelectedDetail(event: CouplingEvent, layer: L.LayerGroup) {
  const pathCoords = event.typhoonPath.map((p) => [p.lat, p.lng] as [number, number])
  const boundsPoints: [number, number][] = []

  if (pathCoords.length > 1) {
    L.polyline(pathCoords, {
      color: '#0f766e',
      weight: 4,
      opacity: 0.95,
      interactive: false,
    }).addTo(layer)

    addPathDirectionArrows(pathCoords, layer, {
      color: '#0f766e',
      every: Math.max(1, Math.floor(pathCoords.length / 2)),
      maxArrows: 1,
      size: 24,
      opacity: 1,
    })

    boundsPoints.push(...pathCoords)
  }

  const tc = event.typhoonAtCoupling
  if (tc) {
    if (event.r30Km != null && event.r30Km > 0) {
      L.circle([tc.lat, tc.lng], {
        radius: event.r30Km * 1000,
        color: '#0d9488',
        fillColor: '#14b8a6',
        fillOpacity: 0.1,
        weight: 1.5,
        dashArray: '4 6',
        interactive: false,
      })
        .bindTooltip(`R30 · ${event.r30Km.toFixed(1)} km`)
        .addTo(layer)
    }

    L.circleMarker([tc.lat, tc.lng], {
      radius: 8,
      color: '#0f766e',
      fillColor: '#2dd4bf',
      fillOpacity: 0.95,
      weight: 2,
      interactive: false,
    })
      .bindPopup(
        `<strong>Typhoon center at coupling · ${typhoonCodeFromZid(event.id)}</strong><br/>${tc.lat.toFixed(2)}°N, ${tc.lng.toFixed(2)}°E<br/>Wind ${event.windMs.toFixed(1)} m/s`,
      )
      .addTo(layer)

    boundsPoints.push([tc.lat, tc.lng])
  }

  addEpicenterLayers(event, layer, { compact: false })
  boundsPoints.push([event.epicenter.lat, event.epicenter.lng])

  return boundsPoints
}

function renderOverview() {
  if (!map || !overviewLayer) return
  overviewLayer.clearLayers()

  const catalog = props.events ?? []
  if (!catalog.length) return

  const selectedId = props.selectedId || props.event?.id
  const japanBounds = L.latLngBounds(JAPAN_VIEW_BOUNDS)

  catalog.forEach((item) => {
    const muted = !!selectedId && item.id !== selectedId
    drawOverviewPath(item, overviewLayer!, muted)

    // ：； selectedLayer ，
    if (item.id === selectedId) return

    const asEvent = catalogItemToMapEvent(item)
    addEpicenterLayers(asEvent, overviewLayer!, {
      compact: true,
      onSelect: selectPair,
    })
  })

  if (!didFitAll) {
    // ，
    map.fitBounds(japanBounds, { padding: [16, 16], maxZoom: 7.2 })
    didFitAll = true
  }
}

function renderSelected() {
  if (!map || !selectedLayer) return
  selectedLayer.clearLayers()

  const catalog = props.events ?? []
  const selectedId = props.selectedId || props.event?.id

  // ：
  if (catalog.length && selectedId) {
    const item = catalog.find((e) => e.id === selectedId)
    if (!item) return
    const event = props.event?.id === selectedId ? props.event : catalogItemToMapEvent(item)
    drawSelectedDetail(event, selectedLayer)
    return
  }

  // ：
  if (!catalog.length && props.event) {
    const bounds = drawSelectedDetail(props.event, selectedLayer)
    //  renderLoss 
    if (props.lossGrids?.length) return

    const japanBounds = L.latLngBounds(JAPAN_VIEW_BOUNDS)
    if (bounds.length >= 2) {
      const local = bounds.filter(([lat, lng]) => japanBounds.contains([lat, lng]))
      const focusPoints = local.length >= 2 ? local : [[props.event.epicenter.lat, props.event.epicenter.lng] as [number, number]]
      if (focusPoints.length >= 2) {
        map.fitBounds(L.latLngBounds(focusPoints), { padding: [40, 40], maxZoom: 8 })
      } else if (focusPoints.length === 1) {
        map.setView(focusPoints[0]!, 7)
      } else {
        map.fitBounds(japanBounds, { padding: [20, 20], maxZoom: 7 })
      }
    } else if (bounds.length === 1) {
      map.setView(bounds[0]!, 7)
    } else {
      map.fitBounds(japanBounds, { padding: [20, 20], maxZoom: 7 })
    }
  }
}

function renderLoss() {
  if (!map || !lossLayer) return
  lossLayer.clearLayers()

  const grids = props.lossGrids ?? []
  if (!grids.length) return

  const bounds = addGridLossLayer(
    grids,
    lossLayer,
    props.gridHalfDeg ?? 0.0041666667,
    props.heatMetric ?? 'loss',
  )

  if (!didFitLoss && !props.events?.length && bounds.length >= 2) {
    const fit = L.latLngBounds(bounds)
    if (props.event) {
      fit.extend([props.event.epicenter.lat, props.event.epicenter.lng])
    }
    map.fitBounds(fit, { padding: [32, 32], maxZoom: 8.5 })
    didFitLoss = true
  }

  requestAnimationFrame(() => map?.invalidateSize())
}

function renderAll() {
  renderLoss()
  renderOverview()
  renderSelected()
}

watch(
  () =>
    [props.events?.length, props.selectedId, props.event?.id, props.lossGrids?.length] as const,
  () => {
    didFitLoss = false
    renderAll()
  },
)

watch(
  () => props.event,
  () => {
    if (!(props.events?.length)) renderSelected()
  },
  { deep: true },
)

watch(
  () => props.lossGrids,
  () => renderLoss(),
  { deep: true },
)

watch(
  () => props.heatMetric,
  () => renderLoss(),
)

onMounted(async () => {
  await nextTick()
  initMap()

  if (mapContainer.value) {
    resizeObserver = new ResizeObserver(() => map?.invalidateSize())
    resizeObserver.observe(mapContainer.value)
  }

  setTimeout(() => map?.invalidateSize(), 200)
  setTimeout(() => map?.invalidateSize(), 600)
})

onUnmounted(() => {
  resizeObserver?.disconnect()
  map?.remove()
  map = null
  overviewLayer = null
  selectedLayer = null
  lossLayer = null
})
</script>

<template>
  <section class="map-panel">
    <div class="map-panel-head">
      <h3>{{ lossGrids?.length ? `${gridHeatMetricLabel(heatMetric ?? 'loss')} · Chiba` : 'Japan map' }}</h3>
      <div class="map-panel-head-right">
        <div v-if="lossGrids?.length" class="heat-metric-control" aria-label="Heatmap metric">
          <button
            v-for="metric in GRID_HEAT_METRICS"
            :key="metric.value"
            type="button"
            class="heat-metric-button"
            :class="{ active: (heatMetric ?? 'loss') === metric.value, [`metric-${metric.value}`]: true }"
            @click="emit('update:heatMetric', metric.value)"
          >
            {{ metric.label }}
          </button>
        </div>
        <div v-if="lossGrids?.length" class="heat-legend heat-legend--inline" :class="`heat-legend--${heatMetric ?? 'loss'}`">
          <span class="heat-legend-label">{{ gridHeatMetricLabel(heatMetric ?? 'loss') }}</span>
          <div class="heat-legend-bar" />
          <span>Low</span>
          <span>High</span>
        </div>
        <span class="map-badge">
          {{
            events?.length
              ? `All ${events.length} pairs · Hover epicenter for typhoon`
              : lossGrids?.length
                ? `${lossGrids.length.toLocaleString()} grid cells`
                : activeTileCredit
          }}
        </span>
      </div>
    </div>
    <div
      ref="mapContainer"
      class="map-container"
      :class="lossGrids?.length ? 'map-container--heatmap' : 'map-container--tall'"
    />
    <p v-if="!(events?.length || event)" class="map-hint">
      After the local catalog loads, all epicenters and full typhoon tracks are shown. Select a pair for details.
    </p>
    <p v-else-if="events?.length" class="map-hint">
      Gray tracks/markers are all coupling pairs. Click an epicenter or track to select one. Hover an epicenter to see the typhoon ID.
      <span class="map-credit">Basemap {{ activeTileCredit }}</span>
    </p>
    <p v-else class="map-hint">
      <template v-if="lossGrids?.length">
        Grid cells colored by {{ gridHeatMetricLabel(heatMetric ?? 'loss') }}. Hover for details.
      </template>
      <template v-else>Loading grid losses…</template>
      <span class="map-credit">Basemap {{ activeTileCredit }}</span>
    </p>
  </section>
</template>
