<script setup lang="ts">
import { computed } from 'vue'
const props = defineProps<{ fileStem?: string; samples?: number; samplingMethod?: string; version?: number; statistics?: Record<string, { sample_mean_million_usd: number; model_expected_million_usd: number }> }>()
const stem = () => props.fileStem || 'Case2005_Chiba_Banyan'
const charts = computed(() => [
  {
    key: 'coupled',
    title: 'Coupled loss',
    subtitle: 'Coupled loss distribution',
    src: `/data/risk-loss/${stem()}_Coupled_loss.png?v=${props.version || 0}`,
    stat: props.statistics?.Coupled,
  },
  {
    key: 'earthquake',
    title: 'Earthquake loss',
    subtitle: 'Earthquake loss distribution',
    src: `/data/risk-loss/${stem()}_Earthquake_loss.png?v=${props.version || 0}`,
    stat: props.statistics?.Earthquake,
  },
  {
    key: 'typhoon',
    title: 'Typhoon loss',
    subtitle: 'Typhoon loss distribution',
    src: `/data/risk-loss/${stem()}_Typhoon_loss.png?v=${props.version || 0}`,
    stat: props.statistics?.Typhoon,
  },
])
</script>

<template>
  <section class="loss-charts-wrap">
    <!-- <header class="section-intro">
      <h2>Loss probability</h2>
      <p>Building loss exceedance curves for coupled, earthquake, and typhoon cases (M USD)</p>
    </header> -->

    <div class="loss-charts">
      <article v-for="chart in charts" :key="chart.key" class="loss-chart-card">
        <header class="loss-chart-card-head">
          <div>
            <h4>{{ chart.title }}</h4>
            <p>{{ chart.subtitle }}</p>
          </div>
          <span v-if="props.samples && props.samplingMethod && props.samplingMethod !== 'unpaired'" class="loss-chart-stat">{{ props.samples.toLocaleString() }} simulations · {{ props.samplingMethod }}</span>
        </header>
        <figure class="loss-chart-figure">
          <img :src="chart.src" :alt="`${chart.title} distribution`" loading="lazy" />
        </figure>
      </article>
    </div>
  </section>
</template>
