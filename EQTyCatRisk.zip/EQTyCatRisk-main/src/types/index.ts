export interface TyphoonPoint {
  lat: number
  lng: number
  windMs?: number
  windKt?: number
  /** （JST） */
  time?: string
}

export interface CouplingEvent {
  id: string
  magnitude: number
  /** ，km/h（ wind_ms ，） */
  windSpeed: number
  /** ，m/s（ wind_ms） */
  windMs: number
  windKt?: number
  year: number
  epicenter: TyphoonPoint
  typhoonPath: TyphoonPoint[]
  descriptions: string[]
  lossByPrefecture: Record<string, number>
  structureLoss: {
    wood: number
    steel: number
    rc: number
    masonry: number
  }
  /**  data/ */
  basin?: string
  couplingType?: string
  /**  km */
  depthKm?: number | null
  pressureHpa?: number | null
  dtHours?: number | null
  distanceKm?: number | null
  r34Km?: number | null
  r30Km?: number | null
  eqTime?: string
  tcTime?: string
  typhoonAtCoupling?: TyphoonPoint | null
  typhoonWinds?: number[]
  sourceIndex?: number
  /** Optional study-area boundary used by the risk map. */
  boundary?: Array<Array<[number, number]>>
}

export interface CouplingCatalogItem {
  id: string
  basin: string | null
  couplingType: string | null
  magnitude: number
  depthKm?: number | null
  windMs: number
  windSpeed: number
  pressureHpa: number | null
  dtHours: number | null
  distanceKm: number | null
  r34Km: number | null
  r30Km?: number | null
  eqTime: string
  tcTime: string
  year?: number | null
  epicenter: TyphoonPoint
  typhoonAtCoupling: TyphoonPoint | null
  typhoonPath: TyphoonPoint[]
  typhoonWinds: number[]
  index: number
}

export interface CouplingCatalogFile {
  version: number
  count: number
  events: CouplingCatalogItem[]
}

export interface Prefecture {
  id: string
  name: string
  lat: number
  lng: number
}

/** ： */
export interface RiskRegion {
  id: string
  name: string
  population: number
  meanPgaGal: number
  meanWindMs: number
  /** ： lossJpy（） */
  lossIndex: number
  /** ，JPY */
  lossJpy?: number
  lat?: number | null
  lng?: number | null
}

/** Risk-page grid loss point (validated without_Other result). */
export interface RiskGridCell {
  lat: number
  lng: number
  lossJpy: number
  population?: number
  name?: string
  pgaGal?: number
  windMs?: number
}

export interface RiskCaseEvent extends CouplingEvent {
  label: string
  depthKm?: number
  typhoonCode?: string
  typhoonName?: string
  regions: RiskRegion[]
  /** （ + JPY） */
  gridCells?: RiskGridCell[]
  /** Study-area outer boundary derived from grid polygons. */
  boundary?: Array<Array<[number, number]>>
  gridHalfDeg?: number
  /**  */
  gridCellsUrl?: string
  totalCoupledLossJpy?: number
  lossByRegion: Record<string, number>
  lossFileStem?: string
}

export interface RiskCaseFile {
  version: number
  event: RiskCaseEvent
}
